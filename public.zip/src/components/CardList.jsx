import { cards } from "../data/cards";
import { List } from "./List";
console.log(cards)
export function CardList(
  id,
  img,
  teamName,
  country,
  city,
  currentPosition,
  minTicketPrice,
  fanRate,
  champions = {}
) {
  
  //   const championRings = "&#128141;".repeat(cards.champions);

  return (
    <>
      <List
        className="team-icon"
        src={img}
        alt="team-icon"
        items={cards}
        field="img"
      ></List>
      <List className="team-card-content-text" items={cards} field="teamName">
        {teamName}
      </List>
     
      <List
        className="team-card-content-text team-country"
        items={cards}
        field="country"
      >
        {country}
      </List>
      <List className="team-card-content-text" items={cards} field="city">
        City:{city}
        console.log
      </List>
      <List className="current-position" items={cards} field="currentPosition">
        Seasonal position:{currentPosition}
      </List>
      <List className="ticket-price" items={cards} field="minTicketPrice">
        Ticket price: {minTicketPrice}
      </List>
      <List className="champions" items={cards} field="champions">
        Champion rings: {champions}
      </List>
      <List className="team-rate" items={cards} field="fanRate">
        Fan Rating: {fanRate}
      </List>
    </>
  );
}
console.log(teamName)