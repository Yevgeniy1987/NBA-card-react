import { CardList } from './components/CardList'
import './App.css'


function App() {
  
  return (
    <>
      <header></header>
      <main>
      <CardList>
       
      </CardList>
      </main>
    </>
  )
}

export default App
